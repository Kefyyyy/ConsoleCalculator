/**
 * 
 */
/**
 * @author kefyyyy
 *
 */
module Calculator {
}